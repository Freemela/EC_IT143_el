-- Question: How do I extract the first name from a full contact name?


SELECT 
    ContactName,
    CASE 
        WHEN CHARINDEX(' ', ContactName) > 0 
        THEN SUBSTRING(ContactName, 1, CHARINDEX(' ', ContactName) - 1)
        ELSE ContactName  -- If no space is found, return the entire name as FirstName
    END AS FirstName
FROM 
    dbo.t_w3_schools_customers;


-- This query retrieves the first name directly from the existing table using string functions.
