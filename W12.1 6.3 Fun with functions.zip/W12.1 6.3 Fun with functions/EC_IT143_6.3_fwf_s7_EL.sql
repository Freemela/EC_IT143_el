/*****************************************************************************************************************
NAME:    EC_IT143_6.3_fwf_s7_EL.sql
PURPOSE:  Ensure the function behaves correctly with edge cases, like inputs without spaces..

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     10/28/2024   Egbebo Luther      1. Built this script for EC IT43 


RUNTIME: 
0:00 01:00s

NOTES: 
 This test checks how the function behaves with edge cases, ensuring robustness in various scenarios.

******************************************************************************************************************/

-- Q1:   What happens if there is no space in the full name?
-- A1: This test confirms the function's behavior when provided an input without spaces.


CREATE OR ALTER FUNCTION dbo.fn_GetFirstName (@FullName NVARCHAR(255))
RETURNS NVARCHAR(255)
AS
BEGIN
    RETURN 
    (
        CASE 
            WHEN CHARINDEX(' ', @FullName) > 0 
            THEN SUBSTRING(@FullName, 1, CHARINDEX(' ', @FullName) - 1)
            ELSE @FullName  -- Returns the entire name if there�s no space
        END
    );
END;


-- Should return 'NoSpaceName'


