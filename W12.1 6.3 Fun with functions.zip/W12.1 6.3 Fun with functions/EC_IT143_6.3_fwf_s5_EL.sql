/*****************************************************************************************************************
NAME:    EC_IT143_6.3_fwf_s5_EL.sql
PURPOSE: Encapsulate the logic for extracting the first name for reuse throughout the database.

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     10/28/2024   Egbebo Luther      1. Built this script for EC IT43 


RUNTIME: 
0:00 01:00s

NOTES: 
 This function encapsulates the logic for extracting the first name, allowing for reuse and improved clarity.
 
******************************************************************************************************************/

-- Q1: What does this function do?
-- A1: This function extracts the first name from a full contact name. 



CREATE FUNCTION dbo.fn_GetFirstName(@FullName VARCHAR(100))
RETURNS VARCHAR(50)
AS
BEGIN
    RETURN SUBSTRING(@FullName, 1, CHARINDEX(' ', @FullName) - 1);
END;


-- 
