-- Question: What string manipulation techniques can I use?
-- I will explore using SUBSTRING and CHARINDEX to isolate the first name.
.
