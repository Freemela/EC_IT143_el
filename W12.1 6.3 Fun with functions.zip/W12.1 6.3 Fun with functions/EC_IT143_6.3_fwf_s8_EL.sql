/*****************************************************************************************************************
NAME:    EC_IT143_6.3_fwf_s8_EL.sql
PURPOSE:  Transition to the next problem, encouraging continuous inquiry and development.


MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     10/28/2024   Egbebo Luther      1. Built this script for EC IT43 


RUNTIME: 
0:00 01:00s

NOTES: 
 This step encourages continuous inquiry, leading to the next problem to solve in the function development process.

******************************************************************************************************************/

-- Q1:   How do I extract the last name from a full contact name?
-- A1: This question leads into the next steps for developing similar functionality for last names.





