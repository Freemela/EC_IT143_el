/*****************************************************************************************************************
NAME:    EC_IT143_6.3_fwf_s6_EL.sql
PURPOSE: Compare UDF results to ad hoc query results.

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     10/28/2024   Egbebo Luther      1. Built this script for EC IT43 


RUNTIME: 
0:00 01:00s

NOTES: 
 This comparison helps verify that my UDF produces accurate results consistent with my earlier query.

******************************************************************************************************************/

-- Q1:  Do the results of the UDF match the ad hoc query results?
-- A1: This script allows for a direct comparison of the function output and ad hoc query results.




SELECT ContactName, 
       dbo.fn_GetFirstName(ContactName) AS FirstNameFunction,
       SUBSTRING(ContactName, 1, CHARINDEX(' ', ContactName) - 1) AS FirstNameAdHoc
FROM dbo.t_w3_schools_customers;




