-- Question: How do I keep track of when a record was last modified?


-- This question frames the purpose of the trigger we are about to create.
 