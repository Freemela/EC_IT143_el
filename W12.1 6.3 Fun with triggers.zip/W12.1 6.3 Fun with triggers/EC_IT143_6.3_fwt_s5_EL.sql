/*****************************************************************************************************************
NAME:    EC_IT143_6.3_fwt_s5_EL.sql
PURPOSE:  Verify that the trigger functions correctly and updates the LastModified timestamp as intended.

MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     10/28/2024   Egbebo Luther      1. Built this script for EC IT43 


RUNTIME: 
0:00 01:00s

NOTES: 
 Verifying that the trigger works correctly ensures the functionality is reliable.
******************************************************************************************************************/

-- Q1:  Did the trigger successfully update the LastModified column?
-- A1:  This test verifies that the trigger is functioning correctly by checking the updated timestamp.



UPDATE dbo.t_w3_schools_customers
SET ContactName = 'Updated Name'
WHERE CustomerID = 1;

SELECT LastModified
FROM dbo.t_w3_schools_customers
WHERE CustomerID = 1;

