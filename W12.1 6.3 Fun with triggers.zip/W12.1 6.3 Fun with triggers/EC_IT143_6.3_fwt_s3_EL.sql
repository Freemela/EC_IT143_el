-- Question: What is the syntax for creating a trigger in SQL Server?


-- I will look up CREATE TRIGGER syntax and examples to ensure I implement it correctly.


-- Note: Research results will be documented separately.
