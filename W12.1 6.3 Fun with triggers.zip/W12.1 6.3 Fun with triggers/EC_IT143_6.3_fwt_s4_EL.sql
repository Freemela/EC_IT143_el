/*****************************************************************************************************************
NAME:    EC_IT143_6.3_fwt_s4_EL.sql
PURPOSE:  Implement a trigger that updates the LastModified column whenever a record is changed.


MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     10/28/2024   Egbebo Luther      1. Built this script for EC IT43 


RUNTIME: 
0:00 01:00s

NOTES: 
 Implementing this trigger updates the LastModified column, fulfilling the requirement to track changes.
******************************************************************************************************************/

-- Q1:  How do I keep track of when a record was last modified?
-- A1:  This trigger updates the LastModified column whenever a record is updated, ensuring we track modifications.
 

CREATE TRIGGER trg_AfterUpdate
ON dbo.t_w3_schools_customers
AFTER UPDATE
AS
BEGIN
    UPDATE t
    SET LastModified = GETDATE()  -- Assuming there's a LastModified column
    FROM dbo.t_w3_schools_customers t
    INNER JOIN inserted i ON t.CustomerID = i.CustomerID;
END;


