-- Question: What type of trigger should I use?



-- I will create an AFTER UPDATE trigger to update the last modified timestamp.
