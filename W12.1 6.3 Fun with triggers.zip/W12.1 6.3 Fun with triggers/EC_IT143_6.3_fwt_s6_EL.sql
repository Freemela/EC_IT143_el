/*****************************************************************************************************************
NAME:    EC_IT143_6.3_fwt_s6_EL.sql
PURPOSE:   Identify additional functionality needed, such as tracking who modified the record.


MODIFICATION LOG:
Ver      Date        Author        Description
-----   ----------   -----------   -------------------------------------------------------------------------------
1.0     10/28/2024   Egbebo Luther      1. Built this script for EC IT43 


RUNTIME: 
0:00 01:00s

NOTES: 
 This prompts me to consider additional functionality, such as tracking who made the last modification.
******************************************************************************************************************/

-- Q1:   How do I keep track of who last modified a record?
-- A1:  This leads to the next steps for adding functionality to track the user who made the last modification.

